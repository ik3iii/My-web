
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function enhanceDescription(title: string, currentDesc: string, lang: 'en' | 'ar'): Promise<string> {
  const prompt = lang === 'en' 
    ? `You are a senior Python developer. Enhance this tool description to make it professional and attractive for a marketplace. Tool Name: ${title}. Current description: ${currentDesc}. Keep it concise but technical.`
    : `أنت مبرمج بايثون خبير. قم بتحسين وصف هذه الأداة لجعلها احترافية وجذابة للسوق البرمجي. اسم الأداة: ${title}. الوصف الحالي: ${currentDesc}. اجعل الوصف موجزاً وتقنياً باللغة العربية.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text?.trim() || currentDesc;
  } catch (error) {
    console.error("Gemini Error:", error);
    return currentDesc;
  }
}

export async function generateToolCategory(title: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest a single category for a Python tool named "${title}". Examples: Automation, Data Science, Web Scraping, AI/ML, CLI Tool, GUI, Bot. Return ONLY the category name.`,
    });
    return response.text?.trim() || "General";
  } catch (error) {
    return "Python Script";
  }
}
