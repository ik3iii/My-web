
import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';

// Removed manual process.env definition to resolve TypeScript errors and comply with security guidelines.
// The environment variable process.env.API_KEY is assumed to be pre-configured by the execution context.

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}