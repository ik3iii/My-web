
import React from 'react';
import { PythonTool, Language, translations } from '../types';

interface ToolCardProps {
  tool: PythonTool;
  lang: Language;
  onView: (tool: PythonTool) => void;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool, lang, onView }) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';

  return (
    <div className="group relative bg-slate-900 border border-white/5 rounded-[2rem] overflow-hidden tool-card-hover cursor-pointer flex flex-col h-full"
         onClick={() => onView(tool)}>
      
      {/* Decorative Header (Replaces Image) */}
      <div className="relative h-44 bg-slate-800/40 overflow-hidden flex items-center justify-center border-b border-white/5">
        <div className="absolute inset-0 opacity-5 pointer-events-none font-mono text-[10px] overflow-hidden p-4 select-none">
          {`import python_lib\nclass Agent:\n  def start(self):\n    return "Processing..."\n# Agent Code Marketplace\n# Secure Scripts\n# Verified Tools\n# Python 3.x\n# Automation Ready`}
        </div>
        
        <div className="relative z-10 w-20 h-20 bg-blue-600/10 rounded-[1.5rem] flex items-center justify-center border border-blue-500/20 group-hover:scale-110 group-hover:bg-blue-600/20 transition-all duration-500 shadow-2xl">
           <svg className="w-10 h-10 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
           </svg>
        </div>
        
        <div className="absolute top-5 left-5 z-20">
          <span className="bg-blue-600/80 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10 shadow-lg">
            {tool.category}
          </span>
        </div>

        <div className="absolute bottom-5 right-5 z-20">
          <div className="bg-white text-slate-950 px-4 py-1.5 rounded-xl text-xs font-black shadow-2xl">
            {tool.price === 'free' ? t.free : `$${tool.price}`}
          </div>
        </div>
      </div>
      
      <div className="p-7 flex-1 flex flex-col">
        <h3 className={`text-xl font-black mb-3 text-white line-clamp-1 group-hover:text-blue-400 transition-colors ${isRtl ? 'font-arabic' : ''}`}>
          {tool.title}
        </h3>
        <p className="text-slate-500 text-sm mb-6 line-clamp-3 min-h-[3.5rem] font-medium leading-relaxed">
          {tool.description}
        </p>
        
        <div className="mt-auto flex items-center justify-between pt-5 border-t border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-slate-800 border border-white/5 flex items-center justify-center text-[10px] font-black text-blue-500">
              {tool.authorName.charAt(0)}
            </div>
            <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">
              {t.by} {tool.authorName}
            </span>
          </div>
          
          <div className="flex items-center gap-2 text-blue-500/50 font-black text-xs">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/>
            </svg>
            {tool.downloads > 999 ? `${(tool.downloads/1000).toFixed(1)}k` : tool.downloads}
          </div>
        </div>
      </div>

      <div className="absolute inset-0 border-2 border-transparent group-hover:border-blue-500/20 rounded-[2rem] transition-all pointer-events-none"></div>
    </div>
  );
};

export default ToolCard;
