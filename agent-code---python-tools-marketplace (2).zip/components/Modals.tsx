
import React, { useState } from 'react';
import { Language, translations, PythonTool } from '../types';
import { enhanceDescription, generateToolCategory } from '../geminiService';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const AuthModal: React.FC<ModalProps & { initialType: 'login' | 'signup', onAuth: (name: string) => void }> = ({ isOpen, onClose, lang, initialType, onAuth }) => {
  const [type, setType] = useState(initialType);
  const [name, setName] = useState('');
  if (!isOpen) return null;
  const t = translations[lang];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAuth(name || (type === 'login' ? 'User' : 'NewUser'));
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-slate-900 border border-white/10 rounded-[2rem] w-full max-w-md p-8 shadow-2xl relative animate-float">
        <button onClick={onClose} className="absolute top-6 right-6 text-slate-500 hover:text-white transition-colors">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>

        {/* Tab Switcher */}
        <div className="flex bg-slate-800 p-1 rounded-2xl mb-8 border border-white/5">
          <button 
            onClick={() => setType('login')}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${type === 'login' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
          >
            {t.login}
          </button>
          <button 
            onClick={() => setType('signup')}
            className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all ${type === 'signup' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
          >
            {t.signup}
          </button>
        </div>

        <h2 className={`text-2xl font-black mb-6 text-white text-center ${lang === 'ar' ? 'font-arabic' : ''}`}>
          {type === 'login' ? t.welcomeBack : t.createAccount}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-5">
          {type === 'signup' && (
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">Username</label>
              <input 
                type="text" 
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-800 border border-white/10 px-5 py-3.5 rounded-2xl text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-600" 
                placeholder="Ex: Python_Agent"
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">Email Address</label>
            <input type="email" required className="w-full bg-slate-800 border border-white/10 px-5 py-3.5 rounded-2xl text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-600" placeholder="dev@agentcode.com" />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">Password</label>
            <input type="password" required className="w-full bg-slate-800 border border-white/10 px-5 py-3.5 rounded-2xl text-white focus:ring-2 focus:ring-blue-500 outline-none transition-all placeholder:text-slate-600" placeholder="••••••••" />
          </div>
          <button className="w-full btn-interact bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-blue-600/20 hover:from-blue-500 hover:to-indigo-500 mt-4">
            {type === 'login' ? t.login : t.signup}
          </button>
        </form>
      </div>
    </div>
  );
};

export const UploadModal: React.FC<ModalProps & { onAdd: (tool: Partial<PythonTool>) => void }> = ({ isOpen, onClose, lang, onAdd }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: '',
    price: 'free' as number | 'free',
    codeSnippet: ''
  });
  const [isEnhancing, setIsEnhancing] = useState(false);

  if (!isOpen) return null;
  const t = translations[lang];

  const handleEnhance = async () => {
    if (!formData.title || !formData.description) return;
    setIsEnhancing(true);
    const enhanced = await enhanceDescription(formData.title, formData.description, lang);
    const suggestedCategory = await generateToolCategory(formData.title);
    setFormData(prev => ({ ...prev, description: enhanced, category: suggestedCategory }));
    setIsEnhancing(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="bg-slate-900 border border-white/10 rounded-[2.5rem] w-full max-w-2xl p-8 md:p-12 shadow-2xl relative overflow-y-auto max-h-[90vh]">
        <button onClick={onClose} className="absolute top-8 right-8 text-slate-500 hover:text-white">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/>
          </svg>
        </button>
        <h2 className={`text-3xl font-black mb-8 text-white ${lang === 'ar' ? 'font-arabic' : ''}`}>
          {t.addTool}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">{t.toolTitle}</label>
              <input 
                required
                type="text" 
                value={formData.title}
                onChange={(e) => setFormData(p => ({...p, title: e.target.value}))}
                className="w-full bg-slate-800 border border-white/10 px-5 py-3 rounded-2xl text-white focus:ring-2 focus:ring-blue-500 outline-none" 
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">{t.toolCategory}</label>
              <input 
                required
                type="text" 
                value={formData.category}
                onChange={(e) => setFormData(p => ({...p, category: e.target.value}))}
                className="w-full bg-slate-800 border border-white/10 px-5 py-3 rounded-2xl text-white focus:ring-2 focus:ring-blue-500 outline-none" 
                placeholder="e.g. Automation"
              />
            </div>
          </div>
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">{t.toolDesc}</label>
              <button 
                type="button"
                onClick={handleEnhance}
                disabled={isEnhancing}
                className="text-[10px] bg-blue-500/10 text-blue-400 px-3 py-1 rounded-full font-black flex items-center gap-1 hover:bg-blue-500/20 disabled:opacity-50 transition-all uppercase"
              >
                <svg className={`w-3 h-3 ${isEnhancing ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                </svg>
                {t.enhanceWithAI}
              </button>
            </div>
            <textarea 
              required
              rows={4}
              value={formData.description}
              onChange={(e) => setFormData(p => ({...p, description: e.target.value}))}
              className="w-full bg-slate-800 border border-white/10 px-5 py-3 rounded-2xl text-white focus:ring-2 focus:ring-blue-500 outline-none resize-none"
            ></textarea>
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">{t.toolCode}</label>
            <input 
              type="text" 
              value={formData.codeSnippet}
              onChange={(e) => setFormData(p => ({...p, codeSnippet: e.target.value}))}
              className="w-full bg-slate-800 border border-white/10 px-5 py-3 rounded-2xl text-white font-mono text-sm focus:ring-2 focus:ring-blue-500 outline-none" 
              placeholder="https://github.com/username/tool"
            />
          </div>
          <div className="flex gap-4 pt-4">
            <button type="button" onClick={onClose} className="flex-1 px-8 py-4 rounded-2xl border border-white/10 font-bold text-slate-400 hover:text-white hover:bg-white/5 transition-all">
              {t.cancel}
            </button>
            <button type="submit" className="flex-[2] btn-interact bg-white text-slate-950 px-8 py-4 rounded-2xl font-black text-lg shadow-xl shadow-white/5">
              {t.submit}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
