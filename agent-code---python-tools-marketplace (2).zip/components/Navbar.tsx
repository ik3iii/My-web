
import React from 'react';
import { Language, translations, User } from '../types';

interface NavbarProps {
  lang: Language;
  setLang: (l: Language) => void;
  user: User | null;
  onLogin: () => void;
  onSignup: () => void;
  onLogout: () => void;
  onUpload: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ lang, setLang, user, onLogin, onSignup, onLogout, onUpload }) => {
  const t = translations[lang];
  const isRtl = lang === 'ar';

  return (
    <nav className="fixed top-0 left-0 right-0 z-[100] glass border-b border-white/5 h-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full">
        <div className="flex justify-between items-center h-full">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-500 to-indigo-600 p-2 rounded-xl shadow-lg shadow-blue-500/20">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
              </svg>
            </div>
            <span className={`text-2xl font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400 ${isRtl ? 'font-arabic' : ''}`}>
              {t.appName}
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            <button 
              onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
              className="px-4 py-2 text-sm font-bold text-slate-400 hover:text-white transition-colors border border-white/10 rounded-xl hover:bg-white/5"
            >
              {lang === 'en' ? 'العربية' : 'English'}
            </button>
            
            {user ? (
              <div className="flex items-center gap-4">
                <button 
                  onClick={onUpload}
                  className="btn-interact bg-blue-600 hover:bg-blue-500 text-white px-6 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-blue-600/20"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                  </svg>
                  {t.upload}
                </button>
                <div className="h-8 w-px bg-white/10 mx-2"></div>
                <div className="flex items-center gap-3 group cursor-pointer">
                  <div className="text-right">
                    <p className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors">{user.name}</p>
                    <button onClick={onLogout} className="text-[10px] text-slate-500 hover:text-red-400 uppercase tracking-widest block font-bold">
                      {t.logout}
                    </button>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center font-black text-blue-500">
                    {user.name.charAt(0)}
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <button 
                  onClick={onLogin}
                  className="text-slate-400 font-bold hover:text-white px-4 transition-colors"
                >
                  {t.login}
                </button>
                <button 
                  onClick={onSignup}
                  className="btn-interact bg-white text-slate-950 px-6 py-2.5 rounded-xl font-bold text-sm shadow-xl shadow-white/5"
                >
                  {t.signup}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
