
export type Language = 'en' | 'ar';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface PythonTool {
  id: string;
  title: string;
  description: string;
  authorId: string;
  authorName: string;
  category: string;
  price: number | 'free';
  downloads: number;
  likes: number;
  codeSnippet?: string;
  createdAt: string;
}

export interface AppState {
  user: User | null;
  language: Language;
  tools: PythonTool[];
  searchQuery: string;
}

export const translations = {
  en: {
    appName: "Agent Code",
    tagline: "The Premier Python Tool Marketplace",
    searchPlaceholder: "Search for scripts, bots, libraries...",
    login: "Login",
    signup: "Sign Up",
    logout: "Logout",
    upload: "Upload Tool",
    myTools: "My Tools",
    home: "Home",
    featured: "Featured Tools",
    allTools: "All Tools",
    download: "Download",
    details: "Details",
    free: "Free",
    by: "by",
    addTool: "Add New Python Tool",
    toolTitle: "Tool Name",
    toolDesc: "Description",
    toolCategory: "Category",
    toolCode: "Sample Snippet / Link",
    submit: "Publish Tool",
    cancel: "Cancel",
    enhanceWithAI: "Enhance with AI",
    about: "About",
    contact: "Contact",
    noTools: "No tools found matching your search.",
    welcomeBack: "Welcome back",
    createAccount: "Create your account"
  },
  ar: {
    appName: "أجينت كود",
    tagline: "سوق أدوات بايثون الرائد",
    searchPlaceholder: "ابحث عن السكربتات، البوتات، المكتبات...",
    login: "تسجيل الدخول",
    signup: "إنشاء حساب",
    logout: "تسجيل الخروج",
    upload: "رفع أداة",
    myTools: "أدواتي",
    home: "الرئيسية",
    featured: "الأدوات المميزة",
    allTools: "جميع الأدوات",
    download: "تحميل",
    details: "التفاصيل",
    free: "مجاني",
    by: "بواسطة",
    addTool: "إضافة أداة بايثون جديدة",
    toolTitle: "اسم الأداة",
    toolDesc: "الوصف",
    toolCategory: "الفئة",
    toolCode: "رابط الأداة / كود برمجي",
    submit: "نشر الأداة",
    cancel: "إلغاء",
    enhanceWithAI: "تحسين بواسطة الذكاء الاصطناعي",
    about: "حول",
    contact: "اتصل بنا",
    noTools: "لم يتم العثور على أدوات تطابق بحثك.",
    welcomeBack: "مرحباً بعودتك",
    createAccount: "أنشئ حسابك الخاص"
  }
};
