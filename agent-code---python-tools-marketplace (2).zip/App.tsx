
import React, { useState, useEffect } from 'react';
import { Language, User, PythonTool, translations } from './types.ts';
import Navbar from './components/Navbar.tsx';
import ToolCard from './components/ToolCard.tsx';
import { AuthModal, UploadModal } from './components/Modals.tsx';

const INITIAL_TOOLS: PythonTool[] = [
  {
    id: '1',
    title: 'Super Scraper X',
    description: 'A lightning fast web scraper optimized for JavaScript-heavy sites. Support async/await and multi-threading.',
    authorId: 'u1',
    authorName: 'DevMaster',
    category: 'Web Scraping',
    price: 'free',
    downloads: 1250,
    likes: 450,
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    title: 'FastAPI Boilerplate Pro',
    description: 'The ultimate production-ready FastAPI starter kit with JWT auth, Postgres integration, and Docker support.',
    authorId: 'u2',
    authorName: 'Backender',
    category: 'Web Framework',
    price: 15,
    downloads: 340,
    likes: 120,
    createdAt: new Date().toISOString()
  },
  {
    id: '3',
    title: 'AI Data Cleaner',
    description: 'Clean your datasets using advanced heuristic models. Removes duplicates, handles missing values, and normalizes types.',
    authorId: 'u3',
    authorName: 'DataViz',
    category: 'Data Science',
    price: 'free',
    downloads: 890,
    likes: 310,
    createdAt: new Date().toISOString()
  },
  {
    id: '4',
    title: 'Crypto Bot Sentinel',
    description: 'Monitor live price changes across multiple exchanges. Integrates with Telegram for instant alerts.',
    authorId: 'u4',
    authorName: 'BotKing',
    category: 'Automation',
    price: 25,
    downloads: 412,
    likes: 98,
    createdAt: new Date().toISOString()
  }
];

const CATEGORIES = ['All', 'Web Scraping', 'Automation', 'Data Science', 'Web Framework', 'AI/ML', 'CLI Tool'];

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('ar');
  const [user, setUser] = useState<User | null>(null);
  const [tools, setTools] = useState<PythonTool[]>(INITIAL_TOOLS);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeModal, setActiveModal] = useState<'login' | 'signup' | 'upload' | null>(null);
  const [selectedTool, setSelectedTool] = useState<PythonTool | null>(null);

  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const t = translations[lang];

  const handleAuth = (name: string) => {
    setUser({ 
      id: Math.random().toString(36).substr(2, 9), 
      name, 
      email: `${name.toLowerCase()}@agentcode.com` 
    });
    setActiveModal(null);
  };

  const handleLogout = () => setUser(null);

  const handleAddTool = (toolData: Partial<PythonTool>) => {
    const newTool: PythonTool = {
      id: Math.random().toString(36).substr(2, 9),
      title: toolData.title || 'Untitled',
      description: toolData.description || '',
      authorId: user?.id || 'guest',
      authorName: user?.name || 'Guest',
      category: toolData.category || 'General',
      price: toolData.price || 'free',
      downloads: 0,
      likes: 0,
      codeSnippet: toolData.codeSnippet,
      createdAt: new Date().toISOString()
    };
    setTools([newTool, ...tools]);
  };

  const filteredTools = tools.filter(tool => {
    const matchesSearch = tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'All' || tool.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className={`min-h-screen bg-[#0f172a] selection:bg-blue-500/30 selection:text-blue-200 transition-all duration-500 ${lang === 'ar' ? 'font-arabic' : ''}`}>
      <Navbar 
        lang={lang} 
        setLang={setLang} 
        user={user} 
        onLogin={() => setActiveModal('login')}
        onSignup={() => setActiveModal('signup')}
        onLogout={handleLogout}
        onUpload={() => setActiveModal('upload')}
      />

      <header className="pt-40 pb-20 px-4 hero-gradient relative overflow-hidden">
        <div className="absolute top-40 right-10 w-64 h-64 bg-blue-600/10 blur-[120px] rounded-full animate-float"></div>
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-indigo-600/10 blur-[150px] rounded-full animate-float" style={{animationDelay: '2s'}}></div>
        
        <div className="max-w-6xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 px-4 py-2 rounded-full mb-8 animate-float">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            <span className="text-xs font-black text-blue-400 uppercase tracking-widest">
              {lang === 'en' ? 'New Tools Added Daily' : 'أدوات جديدة تضاف يومياً'}
            </span>
          </div>
          
          <h1 className="text-5xl md:text-8xl font-black mb-8 tracking-tighter leading-tight text-white drop-shadow-2xl">
            {t.tagline.split(' ').map((word, i) => (
               <span key={i} className={i === 2 ? 'text-blue-500' : ''}>{word} </span>
            ))}
          </h1>
          
          <p className="text-slate-400 text-lg md:text-2xl mb-12 max-w-2xl mx-auto font-medium leading-relaxed">
            {lang === 'en' 
              ? `Elevate your workflow with ${t.appName}. The most advanced hub for verified Python agents and automated scripts.`
              : `ارتقِ بإنتاجيتك مع ${t.appName}. المركز الأكثر تقدماً لوكلاء بايثون الموثقين والسكربتات المؤتمتة.`}
          </p>
          
          <div className="relative max-w-3xl mx-auto group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative">
              <input 
                type="text"
                placeholder={t.searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-10 py-6 md:py-8 rounded-3xl bg-slate-900 border border-white/10 text-white shadow-2xl text-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all pr-20 rtl:pr-10 rtl:pl-20"
              />
              <div className={`absolute top-1/2 -translate-y-1/2 ${lang === 'ar' ? 'left-8' : 'right-8'} text-blue-500`}>
                <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 mb-16 overflow-x-auto whitespace-nowrap scrollbar-hide flex gap-3 pb-4">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-6 py-3 rounded-2xl text-sm font-bold transition-all border ${activeCategory === cat ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-600/20' : 'bg-slate-800/50 border-white/5 text-slate-400 hover:text-white hover:border-white/10'}`}
          >
            {cat}
          </button>
        ))}
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl font-black text-white mb-2">{t.featured}</h2>
            <div className="h-1.5 w-20 bg-blue-600 rounded-full"></div>
          </div>
          <p className="text-slate-500 font-bold text-sm uppercase tracking-widest">
            {filteredTools.length} {lang === 'en' ? 'Results found' : 'نتائج موجودة'}
          </p>
        </div>

        {filteredTools.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredTools.map(tool => (
              <ToolCard 
                key={tool.id} 
                tool={tool} 
                lang={lang} 
                onView={(t) => setSelectedTool(t)} 
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-40 glass rounded-[3rem] border border-white/5">
            <div className="bg-slate-800 w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-8 animate-float">
              <svg className="w-12 h-12 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
              </svg>
            </div>
            <h3 className="text-3xl font-black text-white mb-4">{t.noTools}</h3>
            <p className="text-slate-500 max-w-sm mx-auto">We couldn't find any tool matching your criteria. Try different keywords.</p>
          </div>
        )}
      </main>

      <section className="max-w-7xl mx-auto px-4 mt-32">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <div className="glass p-8 rounded-[2rem] relative overflow-hidden group">
              <div className="absolute -right-4 -bottom-4 text-blue-500/5 group-hover:text-blue-500/10 transition-colors">
                <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
              </div>
              <p className="text-slate-500 font-black text-xs uppercase tracking-widest mb-2">Total Verified</p>
              <h4 className="text-4xl font-black text-white">4,829</h4>
           </div>
           <div className="glass p-8 rounded-[2rem] relative overflow-hidden group border-blue-500/20">
              <div className="absolute -right-4 -bottom-4 text-green-500/5 group-hover:text-green-500/10 transition-colors">
                <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L1 21h22L12 2zm0 3.99L19.53 19H4.47L12 5.99zM11 16h2v2h-2v-2zm0-6h2v4h-2v-4z"/></svg>
              </div>
              <p className="text-slate-500 font-black text-xs uppercase tracking-widest mb-2">Global Downloads</p>
              <h4 className="text-4xl font-black text-white">1.2M+</h4>
           </div>
           <div className="glass p-8 rounded-[2rem] relative overflow-hidden group">
              <div className="absolute -right-4 -bottom-4 text-indigo-500/5 group-hover:text-indigo-500/10 transition-colors">
                <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
              </div>
              <p className="text-slate-500 font-black text-xs uppercase tracking-widest mb-2">Active Creators</p>
              <h4 className="text-4xl font-black text-white">942</h4>
           </div>
        </div>
      </section>

      <footer className="mt-40 py-20 border-t border-white/5 glass">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-10">
          <div className="text-center md:text-left rtl:md:text-right">
            <h3 className="text-2xl font-black text-white mb-2">{t.appName}</h3>
            <p className="text-slate-500 text-sm max-w-xs">Connecting developers with elite Python automation tools.</p>
          </div>
          <div className="flex gap-10 text-xs font-black uppercase tracking-widest text-slate-500">
             <a href="#" className="hover:text-blue-500 transition-colors">Github</a>
             <a href="#" className="hover:text-blue-600 transition-colors">Discord</a>
             <a href="#" className="hover:text-blue-500 transition-colors">API Docs</a>
          </div>
        </div>
      </footer>

      <AuthModal 
        isOpen={activeModal === 'login' || activeModal === 'signup'} 
        initialType={activeModal === 'login' ? 'login' : 'signup'}
        lang={lang}
        onClose={() => setActiveModal(null)}
        onAuth={handleAuth}
      />
      
      <UploadModal 
        isOpen={activeModal === 'upload'}
        lang={lang}
        onClose={() => setActiveModal(null)}
        onAdd={handleAddTool}
      />

      {selectedTool && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 md:p-10 animate-fade-in">
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={() => setSelectedTool(null)}></div>
          <div className="bg-slate-900 border border-white/10 rounded-[3rem] w-full max-w-4xl max-h-[90vh] overflow-hidden shadow-2xl relative flex flex-col">
            <div className="p-8 md:p-16 overflow-y-auto bg-slate-900 scrollbar-hide">
              <button 
                onClick={() => setSelectedTool(null)}
                className="absolute top-8 right-8 bg-white/10 backdrop-blur-md text-white p-3 rounded-2xl hover:bg-white/20 transition-all border border-white/10"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12"/>
                </svg>
              </button>

              <div className="mb-10 text-center md:text-left rtl:md:text-right">
                <span className="bg-blue-600/20 text-blue-400 border border-blue-500/20 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em]">{selectedTool.category}</span>
                <h2 className="text-4xl md:text-6xl font-black text-white mt-6 leading-tight tracking-tighter">{selectedTool.title}</h2>
              </div>
              
              <div className="flex flex-col md:flex-row items-center gap-6 mb-12 pb-10 border-b border-white/5">
                <div className="w-16 h-16 rounded-[1.5rem] bg-blue-600/10 border border-blue-500/20 flex items-center justify-center font-black text-2xl text-blue-500 shrink-0">
                  {selectedTool.authorName.charAt(0)}
                </div>
                <div className="flex-1 text-center md:text-left rtl:md:text-right">
                  <p className="text-[10px] text-slate-500 uppercase font-black tracking-[0.2em] mb-1">{t.by}</p>
                  <p className="text-xl font-bold text-white">{selectedTool.authorName}</p>
                </div>
                <div className="text-center md:text-right">
                   <div className="text-4xl font-black text-white">
                     {selectedTool.price === 'free' ? t.free : `$${selectedTool.price}`}
                   </div>
                </div>
              </div>

              <div className="space-y-6 mb-12">
                <h4 className="text-xs font-black text-slate-500 uppercase tracking-widest">{t.details}</h4>
                <p className="text-slate-400 text-lg leading-relaxed font-medium">
                  {selectedTool.description}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-12">
                 <div className="bg-slate-800/50 p-6 rounded-[2rem] border border-white/5">
                    <p className="text-[10px] text-slate-500 font-black uppercase mb-2 tracking-widest">{lang === 'en' ? 'Verified Installs' : 'تثبيتات موثقة'}</p>
                    <p className="text-3xl font-black text-white">{selectedTool.downloads.toLocaleString()}</p>
                 </div>
                 <div className="bg-slate-800/50 p-6 rounded-[2rem] border border-white/5">
                    <p className="text-[10px] text-slate-500 font-black uppercase mb-2 tracking-widest">{lang === 'en' ? 'Trust Score' : 'معدل الثقة'}</p>
                    <p className="text-3xl font-black text-blue-500">98%</p>
                 </div>
              </div>

              <div className="flex flex-col gap-5">
                <button className="btn-interact w-full bg-white text-slate-950 py-6 rounded-2xl text-2xl font-black shadow-2xl shadow-white/5 flex items-center justify-center gap-3">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  {t.download}
                </button>
                {selectedTool.codeSnippet && (
                   <div className="bg-black/40 p-8 rounded-[2rem] border border-white/5 font-mono text-sm">
                      <div className="flex items-center gap-2 mb-4">
                        <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                        <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                        <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
                        <span className="text-[10px] text-slate-600 font-black ml-4 uppercase tracking-widest">Repository Link</span>
                      </div>
                      <code className="text-blue-400 break-all select-all">{selectedTool.codeSnippet}</code>
                   </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
